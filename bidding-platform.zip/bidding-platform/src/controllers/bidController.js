const { Bid, Item, Notification } = require('../models');
const { io } = require('../config/socket');

const getBidsByItem = async (req, res) => {
  const bids = await Bid.findAll({ where: { item_id: req.params.itemId } });
  res.json(bids);
};

const placeBid = async (req, res) => {
  const { itemId } = req.params;
  const { bid_amount } = req.body;
  const item = await Item.findByPk(itemId);

  if (!item) return res.status(404).json({ error: 'Item not found' });
  if (new Date() > item.end_time) return res.status(400).json({ error: 'Auction has ended' });
  if (bid_amount <= item.current_price) return res.status(400).json({ error: 'Bid must be higher than current price' });

  const bid = await Bid.create({ item_id: itemId, user_id: req.user.id, bid_amount });
  await item.update({ current_price: bid_amount });

  io.emit('update', { itemId, bid_amount });

  // Notify the item owner and the previous highest bidder
  if (req.user.id !== item.user_id) {
    await Notification.create({ user_id: item.user_id, message: `Your item ${item.name} has a new bid of ${bid_amount}` });
  }

  res.status(201).json(bid);
};

module.exports = { getBidsByItem, placeBid };
