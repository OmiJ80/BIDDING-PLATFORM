const { Notification } = require('../models');

const getNotifications = async (req, res) => {
  const notifications = await Notification.findAll({ where: { user_id: req.user.id } });
  res.json(notifications);
};

const markNotificationsAsRead = async (req, res) => {
  await Notification.update({ is_read: true }, { where: { user_id: req.user.id, is_read: false } });
  res.sendStatus(204);
};

module.exports = { getNotifications, markNotificationsAsRead };
