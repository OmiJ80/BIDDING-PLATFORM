const { Item, Bid, Notification } = require('../models');
const { Op } = require('sequelize');

const getAllItems = async (req, res) => {
  const { page = 1, limit = 10, search = '', status } = req.query;
  const offset = (page - 1) * limit;
  const where = {};

  if (search) {
    where.name = { [Op.like]: `%${search}%` };
  }

  if (status === 'active') {
    where.end_time = { [Op.gt]: new Date() };
  } else if (status === 'ended') {
    where.end_time = { [Op.lte]: new Date() };
  }

  const items = await Item.findAndCountAll({ where, limit, offset });
  res.json({ items: items.rows, total: items.count, page, limit });
};

const getItemById = async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(item);
};

const createItem = async (req, res) => {
  const { name, description, starting_price, end_time } = req.body;
  try {
    const item = await Item.create({
      name,
      description,
      starting_price,
      current_price: starting_price,
      image_url: req.file?.path,
      end_time,
      created_at: new Date(),
    });
    res.status(201).json(item);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const updateItem = async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  if (req.user.id !== item.user_id && req.user.role !== 'admin') {
    return res.sendStatus(403);
  }

  const { name, description, starting_price, end_time } = req.body;
  try {
    await item.update({ name, description, starting_price, end_time, image_url: req.file?.path });
    res.json(item);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const deleteItem = async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  if (req.user.id !== item.user_id && req.user.role !== 'admin') {
    return res.sendStatus(403);
  }

  await item.destroy();
  res.sendStatus(204);
};

module.exports = { getAllItems, getItemById, createItem, updateItem, deleteItem };
