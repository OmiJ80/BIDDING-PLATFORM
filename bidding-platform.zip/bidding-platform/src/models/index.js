const sequelize = require('../config/database');
const User = require('./User');
const Item = require('./Item');
const Bid = require('./Bid');
const Notification = require('./Notification');

// Associations
User.hasMany(Bid, { foreignKey: 'user_id' });
Item.hasMany(Bid, { foreignKey: 'item_id' });
User.hasMany(Notification, { foreignKey: 'user_id' });

module.exports = {
  sequelize,
  User,
  Item,
  Bid,
  Notification,
};
