const express = require('express');
const multer = require('multer');
const { getAllItems, getItemById, createItem, updateItem, deleteItem } = require('../controllers/itemController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.get('/', getAllItems);
router.get('/:id', getItemById);
router.post('/', authenticateToken, authorizeRoles('admin', 'user'), upload.single('image'), createItem);
router.put('/:id', authenticateToken, authorizeRoles('admin', 'user'), upload.single('image'), updateItem);
router.delete('/:id', authenticateToken, authorizeRoles('admin', 'user'), deleteItem);

module.exports = router;
